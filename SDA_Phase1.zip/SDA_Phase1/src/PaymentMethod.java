public interface PaymentMethod {
    public void pay();
}
