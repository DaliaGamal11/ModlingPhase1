import java.util.List;

public class UserClass {
    private String Email;
    private String Password;
    private String USerName;
    private Wallet UserWallet;
    public TransctionLog[] USerTransction=new TransctionLog[100];
    public void Signin(String E, String P){
        Email=E;
        Password=P;

    }
    public void Signup(String E, String P, String USerNAme){
        Email=E;
        Password=P;
        USerName=USerNAme;
    }
    public String getEmail(){
        return Email;
    }
    public String getUSerName(){
        return USerName;
    }

    public String getPassword(){
        return Password;
    }
    public void CheckDiscount(){
         Discount D=new Discount();
         D.checkdiscount();
    }
    public void listTransctiion(){
        for(int i=0;i<USerTransction.length;i++){
            System.out.println(USerTransction[i].amount);
            System.out.println(USerTransction[i].TID);
            System.out.println(USerTransction[i].subType);
            System.out.println(USerTransction[i].P);
            System.out.println(USerTransction[i].Type);

        }
    }
}
