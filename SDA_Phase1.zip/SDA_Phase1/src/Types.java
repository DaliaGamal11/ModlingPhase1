public enum Types {
    Payment,Refund,AddToWallet
}
