import java.util.Scanner;

public class DrobMenu implements Field {
    private AbstractForms Form;
    private int Amount;

    public DrobMenu(AbstractForms F){
        Form=F;
    }
    public int makeform() {
        return Form.makeform()+ Amount;
    }

    @Override
    public double cost() {
        return Amount;
    }
}
