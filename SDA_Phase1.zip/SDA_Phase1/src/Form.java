import java.util.Scanner;

public class  Form implements AbstractForms {
    public int makeform() {
        return 0;
    }

    @Override
    public double cost() {
        return 0;
    }


}
