public interface Refund {
    public void requset();
}
