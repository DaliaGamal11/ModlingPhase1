public interface AbstractForms {
    public int makeform();
    public double cost();
}
