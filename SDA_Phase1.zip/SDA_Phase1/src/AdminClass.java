public class AdminClass implements Refund {
    Discount D=new Discount();
    UserClass User;
    @Override
    public void requset() {

    }
    public boolean approved(){
        return true;
    }
    public boolean denied(){
        return false;
    }
    public void AddDiscount(String disc){
           D.discounts.add(disc);
    }
    public  void AddService(String s){
         System.out.println("Service added as a String name But don't have a class ");
    }
    public void listUSerTransction(){
        User.listTransctiion();
    }

}
