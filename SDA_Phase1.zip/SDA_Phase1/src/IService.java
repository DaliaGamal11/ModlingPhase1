public interface IService {
     public IProviders ProviderType(String service);
     public void showlist();
     public PaymentMethod payType(String payType);
     public void showlistofPM();
}
