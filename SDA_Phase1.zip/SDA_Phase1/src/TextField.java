import java.util.Scanner;

public class TextField implements Field {
    private AbstractForms Form;
    private int MobileNo;
    public TextField(AbstractForms F){
        Form=F;
    }
    public int makeform() {
        return Form.makeform()+ MobileNo;
    }

    @Override
    public double cost() {
        return 0;
    }
}
