public class RealRefund implements Refund {
    private int amount;
    @Override
    public void requset() {
        System.out.println("Request is sent");
    }
}
