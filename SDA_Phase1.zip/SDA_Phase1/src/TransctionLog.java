import java.util.LinkedList;
import java.util.List;

public class TransctionLog {
    public String Type;
    public int TID;
    public IProviders P;
    public  String subType;
    public int amount;

}
