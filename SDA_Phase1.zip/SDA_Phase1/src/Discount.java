import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Discount {
     Queue<String>discounts=new LinkedList<>();
      public void checkdiscount(){
          System.out.println(discounts);
      }
      public Discount(){
          discounts.add("Overall");
          discounts.add("Specfic");
      }



}
